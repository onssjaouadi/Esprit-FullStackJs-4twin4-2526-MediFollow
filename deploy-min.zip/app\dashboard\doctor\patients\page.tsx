import { redirect } from "next/navigation";
import Link from "next/link";
import { AlertCircle, Activity, Calendar, Phone } from "lucide-react";
import { getCurrentUser } from "@/lib/actions/auth.actions";
import { getPatientsByDoctorSpecialty } from "@/lib/actions/patient.actions";
import { getDoctorProfile } from "@/lib/actions/doctor.actions";
import { Badge } from "@/components/ui/badge";

export default async function DoctorPatientsPage() {
  const user = await getCurrentUser();

  if (!user || user.role !== "DOCTOR") {
    redirect("/login");
  }

  // Get doctor's specialty and patients matching that specialty
  const doctorProfile = await getDoctorProfile(user.id);
  const patients = await getPatientsByDoctorSpecialty(user.id);

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
          Patients
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Gérez et surveillez vos patients
        </p>
        {doctorProfile?.data?.specialty && (
          <p className="text-sm text-green-600 dark:text-green-400 mt-2 font-medium">
            Spécialité:{" "}
            <span className="capitalize">{doctorProfile.data.specialty}</span>
          </p>
        )}
      </div>

      {/* Search and Filters */}
      <div className="mb-6 flex gap-4">
        <input
          type="text"
          placeholder="Rechercher par nom ou numéro de dossier..."
          className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:focus:ring-green-400"
        />
        <select
          title="Filtrer par statut"
          className="px-4 py-2 border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:focus:ring-green-400"
        >
          <option value="">Tous les statuts</option>
          <option value="active">Actif</option>
          <option value="critical">Critique</option>
          <option value="stable">Stable</option>
        </select>
      </div>

      {/* Patients Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {patients.map((patient) => {
          const fullName = `${patient.user.firstName} ${patient.user.lastName}`;
          const activeAlerts =
            patient.alerts?.filter((a) => a.status === "OPEN").length || 0;

          return (
            <Link
              key={patient.id}
              href={`/dashboard/doctor/patients/${patient.id}`}
              className="block bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg p-6 hover:shadow-lg transition-shadow"
            >
              {/* Patient Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-green-100 dark:bg-green-500/10 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 font-semibold text-lg">
                    {patient.user.firstName.charAt(0)}
                    {patient.user.lastName.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">
                      {fullName}
                    </h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      MRN: {patient.medicalRecordNumber}
                    </p>
                  </div>
                </div>
                {activeAlerts > 0 && (
                  <Badge
                    variant="destructive"
                    className="flex items-center gap-1"
                  >
                    <AlertCircle className="w-3 h-3" />
                    {activeAlerts}
                  </Badge>
                )}
              </div>

              {/* Patient Info */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Calendar className="w-4 h-4" />
                  <span>
                    {new Date().getFullYear() -
                      new Date(patient.dateOfBirth).getFullYear()}{" "}
                    ans
                  </span>
                  <span className="text-gray-400 dark:text-gray-600">•</span>
                  <span>{patient.gender}</span>
                </div>

                {patient.user.phoneNumber && (
                  <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                    <Phone className="w-4 h-4" />
                    <span>{patient.user.phoneNumber}</span>
                  </div>
                )}

                {patient.diagnosis && (
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    <span className="font-medium">Diagnostic:</span>{" "}
                    {patient.diagnosis}
                  </div>
                )}
              </div>

              {/* Latest Vitals */}
              {patient.vitalRecords && patient.vitalRecords.length > 0 && (
                <div className="border-t border-gray-200 dark:border-gray-800 pt-3">
                  <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-2">
                    <Activity className="w-4 h-4" />
                    <span>Derniers signes vitaux</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {patient.vitalRecords[0].heartRate && (
                      <div>
                        <span className="text-gray-500 dark:text-gray-400">
                          FC:
                        </span>{" "}
                        <span className="font-medium text-gray-900 dark:text-white">
                          {patient.vitalRecords[0].heartRate} bpm
                        </span>
                      </div>
                    )}
                    {patient.vitalRecords[0].systolicBP &&
                      patient.vitalRecords[0].diastolicBP && (
                        <div>
                          <span className="text-gray-500 dark:text-gray-400">
                            TA:
                          </span>{" "}
                          <span className="font-medium text-gray-900 dark:text-white">
                            {patient.vitalRecords[0].systolicBP}/
                            {patient.vitalRecords[0].diastolicBP}
                          </span>
                        </div>
                      )}
                    {patient.vitalRecords[0].temperature && (
                      <div>
                        <span className="text-gray-500">Temp:</span>{" "}
                        <span className="font-medium">
                          {patient.vitalRecords[0].temperature}°C
                        </span>
                      </div>
                    )}
                    {patient.vitalRecords[0].oxygenSaturation && (
                      <div>
                        <span className="text-gray-500">SpO2:</span>{" "}
                        <span className="font-medium">
                          {patient.vitalRecords[0].oxygenSaturation}%
                        </span>
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-gray-400 mt-2">
                    {new Date(
                      patient.vitalRecords[0].recordedAt
                    ).toLocaleDateString("fr-FR", {
                      day: "numeric",
                      month: "short",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              )}

              {/* Status Badge */}
              <div className="mt-4 pt-3 border-t">
                <Badge
                  variant={activeAlerts > 0 ? "destructive" : "secondary"}
                  className="w-full justify-center"
                >
                  {activeAlerts > 0
                    ? `${activeAlerts} alerte(s) active(s)`
                    : "Stable"}
                </Badge>
              </div>
            </Link>
          );
        })}
      </div>

      {patients.length === 0 && (
        <div className="text-center py-12 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800">
          <p className="text-gray-600 dark:text-gray-400 mb-2">
            Aucun patient trouvé
          </p>
          {doctorProfile?.data?.specialty && (
            <p className="text-sm text-gray-500 dark:text-gray-500">
              Aucun patient n'a le diagnostic correspondant à votre spécialité:{" "}
              <span className="font-medium capitalize">
                {doctorProfile.data.specialty}
              </span>
            </p>
          )}
          {!doctorProfile?.data?.specialty && (
            <p className="text-sm text-gray-500 dark:text-gray-500">
              Veuillez définir votre spécialité dans votre profil
            </p>
          )}
        </div>
      )}
    </div>
  );
}
